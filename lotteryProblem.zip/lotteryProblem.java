import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		System.out.println("Welcome to the lottery  ");
		System.out.println("");
		System.out.println("How it work?  ");
		System.out.println("We generat a random number with two digit  ");     	System.out.println("You should input a two digit number  ");
		System.out.println("If the your input matches the lottery in exact order, the award is  $10,000");
		System.out.println("If the your input matches the lottery,  the award  is $3,000");
		System.out.println("If one digit in the user input matches a digit in the lottery,  the award is $1,000 ");
		System.out.println("");
		System.out.print("input a two digit number from 10 to 99 =  ");
		
		Scanner input = new Scanner(System.in);
		int u=input.nextInt();
		if (9<u && u<100) {
		int u1 =(u%10);
		int u2 =(int)(u/10);

	//	int x=(int)(Math.random()*100);
		;int x=(int)(Math.random()*(99-10+1)+10);
		int x1 =(x%10);
		int x2 =(int)(x/10);

		if (u1==x1 && u2==x2) {
		    System.out.println("congrulation !!  your are win 10,000$");
		}
		else if (u1==x2 && u2==x1) {
		    System.out.println("congrulation !!  your are win 3000$");
		}
		else if (u1==x1 || u2==x2) {
		    System.out.println("congrulation !!  your are win 1000$");
		}
		else if (u1==x2 || u2==x1) {
		    System.out.println("congrulation !!  your are win 1000$");
		}
		else {
		   System.out.println("you are not win");
		    }
		System.out.print("the random number was = ");
		System.out.println(x);
		}
		else {
		    System.out.println("invalid imput !");
		}
		
	}
}