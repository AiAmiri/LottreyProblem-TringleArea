import java.util.Scanner;

public class ComputeAngle {
	public static void main(String[] args) {
	    
	    System.out.println("Angle of tigone");
	    System.out.println("");
	    
	    double x1;
	    double y1;
	    double x2;
	    double y2;
	    double x3;
	    double y3;
	    
	    Scanner input = new Scanner (System.in);
	    System.out.print("enter     x1=");
	    x1= input.nextDouble();
	    System.out.print("enter     y1=");
	    y1= input.nextDouble();
	    System.out.print("enter     x2=");
	    x2= input.nextDouble();
	    System.out.print("enter     y2=");
	    y2= input.nextDouble();
	    System.out.print("enter     x3=");
	    x3= input.nextDouble();
	    System.out.print("enter     y3=");
	    y3= input.nextDouble();
	    
	    double a=Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
	    double b=Math.sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
	    double c=Math.sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    
	     System.out.println("a = "+a);
	     System.out.println("b = "+b);
	     System.out.println("c = "+c);
	     
	     double P=Math.PI;
	     
	     double A=Math.acos((a*a-b*b-c*c)/(-2*b*c));
	     System.out.println("Angle of A = "+A*180/P);
	     double B=Math.acos((b*b-a*a-c*c)/(-2*a*c));
	     System.out.println("Angle of B =  "+ B*180/P);
	     double C=Math.acos((c*c-b*b-a*a)/(-2*b*a));
	     System.out.println("Angle of C = "+C*180/P);
	}}